# 🏁 Formula 1 Quiz Multiplayer

## 📄 Documento Completo Progetto

## 📌 Descrizione del progetto

Questo progetto consiste nella realizzazione di un gioco multiplayer online sviluppato con:

* Flutter Web per il client grafico
* Dart TCP/WebSocket Server per la logica multiplayer

Il gioco è un quiz a tema Formula 1 in cui due giocatori si sfidano rispondendo a 10 domande.

Ogni giocatore si collega al server tramite WebSocket e può giocare contemporaneamente contro un altro utente.

---

# 🎮 Funzionamento del gioco

## Obiettivo

Rispondere correttamente al maggior numero possibile di domande sulla Formula 1.

---

# 👥 Modalità Multiplayer

Il gioco supporta:

* 2 giocatori online
* partita in tempo reale
* gestione indipendente delle domande
* punteggio finale condiviso

Ogni giocatore può:

* rispondere senza aspettare l’altro
* completare il quiz in autonomia
* attendere il risultato finale

---

# 🧠 Funzionalità implementate

## ✅ Server Multiplayer

Il server:

* accetta connessioni WebSocket
* gestisce i giocatori connessi
* invia le domande
* controlla le risposte
* calcola il punteggio
* determina il vincitore finale

---

## ✅ Client Flutter Web

Il client:

* mostra interfaccia grafica responsive
* riceve domande dal server
* invia risposte
* visualizza stato della partita
* mostra recap finale

---

## ✅ Recap Finale

Al termine della partita viene mostrato:

* punteggio finale
* vincitore
* riepilogo delle domande
* risposta data
* risposta corretta

Colori utilizzati:

* 🟩 Verde = risposta corretta
* 🟥 Rosso = risposta sbagliata

---

# 🛠️ Tecnologie utilizzate

| Tecnologia  | Utilizzo               |
| ----------- | ---------------------- |
| Flutter Web | Interfaccia grafica    |
| Dart        | Linguaggio principale  |
| WebSocket   | Comunicazione realtime |
| HttpServer  | Server multiplayer     |

---

# 📂 Struttura del progetto

```text
formula1_quiz/
│
├── lib/
│   └── main.dart
│
├── server/
│   └── server.dart
│
└── pubspec.yaml
```

---

# 🚀 Avvio del progetto

## 1️⃣ Avviare il server

Aprire il terminale nella cartella `server` ed eseguire:

```bash
cd server
 dart run server.dart
```

Se tutto funziona apparirà:

```text
🏁 Server avviato
```

---

# 2️⃣ Avviare Flutter Web

Aprire un nuovo terminale nella cartella principale del progetto:

```bash
flutter run -d chrome
```

Flutter aprirà automaticamente Chrome.

---

# 3️⃣ Avviare il secondo giocatore

Per simulare il multiplayer:

* aprire una seconda tab del browser
  oppure
* duplicare la finestra Chrome

Ogni tab rappresenta un giocatore diverso.

Quando entrano due giocatori il quiz parte automaticamente.

---

# 🎯 Regole del gioco

* ogni partita contiene 10 domande
* ogni risposta corretta vale 1 punto
* vince chi ottiene più punti
* in caso di parità viene mostrato “Pareggio”

---

# 🔄 Comunicazione Client-Server

La comunicazione avviene tramite WebSocket.

Il server invia messaggi JSON con diversi tipi:

| Tipo     | Funzione         |
| -------- | ---------------- |
| waiting  | attesa giocatore |
| question | invio domanda    |
| end      | fine partita     |

---

# 📸 Interfacce presenti

L’applicazione presenta:

* schermata di attesa
* schermata quiz
* schermata fine partita
* recap risposte

---

# 🏆 Risultato finale

Il progetto realizza un sistema multiplayer completo che utilizza:

* comunicazione realtime
* sincronizzazione utenti
* gestione stato partita
* interfaccia grafica web

Il gioco rispetta le richieste della consegna:

✅ server TCP/WebSocket
✅ gestione turni e logica
✅ client mobile/web grafico
✅ multiplayer online
✅ interazione realtime
