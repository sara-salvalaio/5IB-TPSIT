import 'dart:convert';
import 'dart:html';

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

WebSocket? socket;

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String status = 'Connessione al server...';

  String question = '';

  List answers = [];

  bool ended = false;

  int finalScore = 0;

  String winner = '';

  List recap = [];

  bool waitingEnd = false;

  @override
  void initState() {
    super.initState();

    connect();
  }

  void connect() {
    socket = WebSocket('ws://localhost:4040');

    socket!.onOpen.listen((event) {
      setState(() {
        status = 'Connesso 🟢';
      });
    });

    socket!.onMessage.listen((event) {
      final data = jsonDecode(event.data);

      if (data['type'] == 'waiting') {
        setState(() {
          status = 'Attesa secondo giocatore...';
        });
      }

      if (data['type'] == 'question') {
        setState(() {
          question = data['question'];

          answers = data['answers'];
        });
      }

      if (data['type'] == 'end') {
        setState(() {
          ended = true;

          finalScore = data['score'];

          winner = data['winner'];

          recap = data['recap'];
        });
      }
    });
  }

  void sendAnswer(String answer) {
    socket!.send(answer);

    setState(() {
      question = '';

      answers = [];

      waitingEnd = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🏁 Formula 1 Quiz'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ended
            ? ListView(
                children: [
                  const Text(
                    '🏆 Fine Partita',
                    style: TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 20),

                  Text(
                    'Vincitore: $winner',
                    style: const TextStyle(
                      fontSize: 24,
                    ),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    'Punteggio Finale: $finalScore / 10',
                    style: const TextStyle(
                      fontSize: 24,
                    ),
                  ),

                  const SizedBox(height: 30),

                  const Text(
                    '📋 Recap Risposte',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 20),

                  ...recap.map((item) {
                    bool correct = item['correct'];

                    return Card(
                      color: correct
                          ? Colors.green.shade200
                          : Colors.red.shade200,
                      child: Padding(
                        padding:
                            const EdgeInsets.all(15),
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['question'],
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),

                            const SizedBox(height: 10),

                            Text(
                              'Tua risposta: ${item['answer']}',
                              style: const TextStyle(
                                fontSize: 18,
                              ),
                            ),

                            Text(
                              'Risposta corretta: ${item['correctAnswer']}',
                              style: const TextStyle(
                                fontSize: 18,
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  }).toList()
                ],
              )
            : question.isEmpty
                ? Center(
                    child: waitingEnd
                        ? const Text(
                            '⏳ Hai completato il quiz.\nAttendi l’altro giocatore...',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 28,
                            ),
                          )
                        : Text(
                            status,
                            style: const TextStyle(
                              fontSize: 28,
                            ),
                          ),
                  )
                : Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        question,
                        style: const TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 30),

                      ...answers.map((answer) {
                        return Padding(
                          padding:
                              const EdgeInsets.only(
                            bottom: 15,
                          ),
                          child: ElevatedButton(
                            onPressed: () {
                              sendAnswer(answer);
                            },
                            child: Padding(
                              padding:
                                  const EdgeInsets.all(
                                15,
                              ),
                              child: Text(
                                answer,
                                style:
                                    const TextStyle(
                                  fontSize: 20,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList()
                    ],
                  ),
      ),
    );
  }
}