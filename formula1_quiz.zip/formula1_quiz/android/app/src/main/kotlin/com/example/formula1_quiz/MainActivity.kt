package com.example.formula1_quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
