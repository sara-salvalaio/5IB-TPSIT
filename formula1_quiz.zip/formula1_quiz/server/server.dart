import 'dart:convert';
import 'dart:io';

List<WebSocket> players = [];

List<Map<String, dynamic>> questions = [
  {
    "question": "Chi ha vinto il mondiale F1 2021?",
    "answers": [
      "Hamilton",
      "Verstappen",
      "Leclerc",
      "Vettel"
    ],
    "correct": "Verstappen"
  },
  {
    "question": "Quale team usa il cavallino rampante?",
    "answers": [
      "Ferrari",
      "Mercedes",
      "Red Bull",
      "McLaren"
    ],
    "correct": "Ferrari"
  },
  {
    "question": "In quale nazione si trova Monza?",
    "answers": [
      "Italia",
      "Spagna",
      "Germania",
      "Francia"
    ],
    "correct": "Italia"
  },
  {
    "question": "Quanti mondiali ha vinto Schumacher?",
    "answers": [
      "5",
      "6",
      "7",
      "8"
    ],
    "correct": "7"
  },
  {
    "question": "Chi è The Iceman?",
    "answers": [
      "Alonso",
      "Raikkonen",
      "Perez",
      "Bottas"
    ],
    "correct": "Raikkonen"
  },
  {
    "question": "Quale team domina l'era ibrida?",
    "answers": [
      "Mercedes",
      "Ferrari",
      "Williams",
      "McLaren"
    ],
    "correct": "Mercedes"
  },
  {
    "question": "Quale pilota usa il numero 44?",
    "answers": [
      "Hamilton",
      "Leclerc",
      "Sainz",
      "Norris"
    ],
    "correct": "Hamilton"
  },
  {
    "question": "Dove si corre il GP di Monaco?",
    "answers": [
      "Monte Carlo",
      "Parigi",
      "Marsiglia",
      "Nizza"
    ],
    "correct": "Monte Carlo"
  },
  {
    "question":
        "Quale team appartiene alla bevanda energetica austriaca?",
    "answers": [
      "Ferrari",
      "Haas",
      "Red Bull",
      "Alpine"
    ],
    "correct": "Red Bull"
  },
  {
    "question":
        "Chi corre con Leclerc in Ferrari nel 2024?",
    "answers": [
      "Sainz",
      "Hamilton",
      "Russell",
      "Vettel"
    ],
    "correct": "Sainz"
  }
];

Map<WebSocket, int> scores = {};

Map<WebSocket, int> indexes = {};

Map<WebSocket, List<Map<String, dynamic>>> recap = {};

Map<WebSocket, bool> finished = {};

void main() async {
  final server =
      await HttpServer.bind('localhost', 4040);

  print('🏁 Server avviato');

  await for (HttpRequest request in server) {
    if (WebSocketTransformer.isUpgradeRequest(
      request,
    )) {
      WebSocket socket =
          await WebSocketTransformer.upgrade(
        request,
      );

      players.add(socket);

      scores[socket] = 0;

      indexes[socket] = 0;

      recap[socket] = [];

      finished[socket] = false;

      print('🧑 Giocatore connesso');

      socket.add(
        jsonEncode({
          "type": "waiting"
        }),
      );

      socket.listen(
        (data) {
          handleAnswer(socket, data);
        },
        onDone: () {
          players.remove(socket);

          print('❌ Giocatore disconnesso');
        },
      );

      if (players.length == 2) {
        for (var p in players) {
          sendQuestion(p);
        }
      }
    }
  }
}

void sendQuestion(WebSocket player) {
  int index = indexes[player]!;

  if (index >= questions.length) {
    finished[player] = true;

    checkEndGame();

    return;
  }

  final q = questions[index];

  player.add(
    jsonEncode({
      "type": "question",
      "question": q['question'],
      "answers": q['answers']
    }),
  );
}

void handleAnswer(
  WebSocket player,
  String answer,
) {
  int index = indexes[player]!;

  final q = questions[index];

  bool correct =
      answer == q['correct'];

  if (correct) {
    scores[player] =
        scores[player]! + 1;
  }

  recap[player]!.add({
    "question": q['question'],
    "answer": answer,
    "correctAnswer": q['correct'],
    "correct": correct
  });

  indexes[player] = index + 1;

  sendQuestion(player);
}

void checkEndGame() {
  if (!finished.values.every(
    (e) => e == true,
  )) {
    return;
  }

  int score1 = scores[players[0]]!;

  int score2 = scores[players[1]]!;

  String winner;

  if (score1 > score2) {
    winner = 'Giocatore 1';
  } else if (score2 > score1) {
    winner = 'Giocatore 2';
  } else {
    winner = 'Pareggio';
  }

  for (var player in players) {
    player.add(
      jsonEncode({
        "type": "end",
        "winner": winner,
        "score": scores[player],
        "recap": recap[player]
      }),
    );
  }

  print('🏆 Partita terminata');
}